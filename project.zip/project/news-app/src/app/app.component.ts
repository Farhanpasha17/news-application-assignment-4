import {
	Component
} from '@angular/core';
import {
	NewsApiService
} from './news-api.service';


@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})
export class AppComponent {

	mArticles: Array < any > ;
	mSources: Array < any > ;

	language: string = "in";
	category: string = "health"

	constructor(private newsapi: NewsApiService) {
		console.log('app component constructor called');
	}


	ngOnInit() {

		this.mSources = [{
			"name":"general",
			"id":1,
			"src":"../assets/icons/general.png"
		  },{
			"name":"science",
			"id":2,
			 "src":"../assets/icons/science.png"
		  },
		  {
			"name":"technology",
			"id":3,
			 "src":"../assets/icons/technology.png"
		  },
		  {
			"name":"entertainment",
			"id":4,
			 "src":"../assets/icons/entertainment.png"
		  },
		  {
			"name":"sports",
			"id":5,
			"src":"../assets/icons/sports.png"
		  },
		  {
			"name":"business",
			"id":6,
			"src":"../assets/icons/business.png"
		  },
		  {
			"name":"health",
			"id":7,
			"src":"../assets/icons/health.png"
		  
		  	}	];

		this.getArticlesBasedOnCategory(this.category, this.language);

	}

	getArticlesBasedOnLanguage(language) {
		this.getArticlesBasedOnCategory(this.category, language);
	}

	getArticlesBasedOnCategory(category, language) {

		this.language = language;
		this.category = category;

		this.newsapi.initArticles(this.language, this.category).subscribe(data => this.mArticles = data['articles']);

	}


	searchArticles(category) {
		console.log("selected category is: " + category);
		this.category = category;
		this.newsapi.getArticlesByID(category, this.language).subscribe(data => this.mArticles = data['articles']);
	}


}


// import {
// 	Component
// } from '@angular/core';
// import {
// 	NewsApiService
// } from './news-api.service';
// import {
// 	HttpClient
// } from '@angular/common/http';

// @Component({
// 	selector: 'app-root',
// 	templateUrl: './app.component.html',
// 	styleUrls: ['./app.component.css']
// })
// export class AppComponent {

// 	mArticles: Array < any > ;
// 	mSources: Array < any > ;

// 	constructor(private newsapi: NewsApiService) {
// 		console.log('app component constructor called');
// 	}

// 	ngOnInit() {
// 		//load articles
// 		this.headlines("en");
// 		//load news sources
// 		this.newsapi.initSources("en").subscribe(data => this.mSources = data['sources']);
// 	}


// 	selectLanguage(lang: string) {

// 		this.headlines(lang);

// 		this.newsapi.initSources(lang).subscribe((data) => {
// 			this.mSources = data['sources'];
// 			this.newsapi.initArticles(lang).subscribe(data => this.mArticles = data['articles']);

// 		});

// 	}


// 	headlines(language: String) {
// 		this.newsapi.headlines(language).subscribe(data => this.mArticles = data['articles']);
// 	}

// 	searchArticles(source,lang) {

// 		console.log("selected source is: " + source);
// 		this.newsapi.getArticlesByID(source,lang).subscribe(data => this.mArticles = data['articles']);
// 	}

// }